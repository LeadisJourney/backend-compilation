package main

import (
	// "os"
	"fmt"
	"golang.org/x/net/context"

	"github.com/docker/engine-api/client"
	"github.com/docker/engine-api/types"
	"github.com/docker/engine-api/types/container"
	"github.com/docker/engine-api/types/strslice"
)

type User struct {
	volume string
	id string
}

func initConfig() (config *container.Config) {
	mount := map[string]struct{}{"/root/host": {}}
	return &container.Config{Image: "leadis_image", Volumes: mount, Cmd: strslice.StrSlice{"date"}}
}

func main() {
	cli, err := client.NewEnvClient()
	if err != nil {
		fmt.Println("error new client:", err)
		return
	}

	cwd, _ := os.Getwd()
	ctx, err := os.Open(cwd+"/dockerfile.tar.gz")
	if err != nil {
		fmt.Println("error open:", err)
		return
	}
	_, err = cli.ImageBuild(context.Background(), types.ImageBuildOptions{Tags: []string{"leadis_image"}, Remove: true, Context: ctx, SuppressOutput: false})
	if err != nil {
		fmt.Println("error build image:", err)
		return
	}

	config := initConfig()
	cresp, err := cli.ContainerCreate(config, nil, nil, "")
	if err != nil {
		fmt.Println("error create container:", err)
		return
	}
	
	err = cli.ContainerStart(cresp.ID)
	if err != nil {
		fmt.Println("error start container:", err)
	}
}
