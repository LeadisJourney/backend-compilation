#ifndef     LA_MEILLEURE
# define    LA_MEILLEURE

extern "C" {

    int la_meilleure(int, int, int);

}

#endif  /* LA_MEILLEURE */
